
export default function Setting() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[80vh] bg-gray-50 text-center px-4">
      <h2 className="text-2xl font-semibold mb-4">Setting</h2>
      <p className="text-gray-600">Coming Soon...</p>
    </div>
  )
}
